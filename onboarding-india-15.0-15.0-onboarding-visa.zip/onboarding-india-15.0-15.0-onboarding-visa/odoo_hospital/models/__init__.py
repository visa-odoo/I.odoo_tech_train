from . import patients
from . import doctor
from . import appointment
from . import sale
